These are all made with PSD151.  Older versions are corrupt.

All padstacks needed for PETSCAN are in this folder.  Please do not copy padstacks from other folders into this one.

Always quit PadStack Editor after you make each new pad and start it fresh.